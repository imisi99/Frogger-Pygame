<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="buildings" tilewidth="64" tileheight="64" tilecount="195" columns="13">
 <image source="../graphics/tilesets/buildings.png" width="832" height="960"/>
</tileset>
